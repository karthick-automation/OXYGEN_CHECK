#include "stm32f4xx.h"

#include <stdint.h>

#include <stdio.h>

#define SENSOR_UART USART1

#define PC_UART     USART2

#define LCD_ADDR    0x27U

#define LCD_RS      0x01U

#define LCD_EN      0x04U

#define LCD_BL      0x08U

static const uint8_t sensor_cmd[4] = {

    0x11, 0x01, 0x01, 0xED

};

/* ================= DELAY ================= */

void delay_ms(uint32_t ms)

{

    while (ms--)

    {

        SysTick->VAL = 0;

        while (!(SysTick->CTRL &

                 SysTick_CTRL_COUNTFLAG_Msk))

        {

        }

    }

}

/* ================= UART ================= */

void UART_SendByte(USART_TypeDef *uart, uint8_t data)

{

    while (!(uart->SR & USART_SR_TXE))

    {

    }

    uart->DR = data;

}

void UART_SendString(USART_TypeDef *uart, const char *str)

{

    while (*str)

    {

        UART_SendByte(uart, (uint8_t)*str++);

    }

}

int UART_ReadByte(USART_TypeDef *uart,

                  uint8_t *data,

                  uint32_t timeout)

{

    while (timeout--)

    {

        if (uart->SR & USART_SR_RXNE)

        {

            *data = (uint8_t)uart->DR;

            return 1;

        }

    }

    return 0;

}

/* ================= UART INIT ================= */

void UART_Init(void)

{

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;

    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* PA9, PA10, PA2, PA3 alternate function */

    GPIOA->MODER &= ~((3U << 18) |

                      (3U << 20) |

                      (3U << 4)  |

                      (3U << 6));

    GPIOA->MODER |=  ((2U << 18) |

                      (2U << 20) |

                      (2U << 4)  |

                      (2U << 6));

    /* AF7 for USART1 and USART2 */

    GPIOA->AFR[1] &= ~((15U << 4) | (15U << 8));

    GPIOA->AFR[1] |=  ((7U << 4) | (7U << 8));

    GPIOA->AFR[0] &= ~((15U << 8) | (15U << 12));

    GPIOA->AFR[0] |=  ((7U << 8) | (7U << 12));

    GPIOA->PUPDR &= ~((3U << 20) | (3U << 6));

    GPIOA->PUPDR |=  ((1U << 20) | (1U << 6));

    USART1->CR1 = 0;

    USART2->CR1 = 0;

    /* HSI 16 MHz, APB1 and APB2 at 16 MHz */

    USART1->BRR = 0x0683U;   /* 9600 baud */

    USART2->BRR = 0x008BU;   /* 115200 baud */

    USART1->CR1 = USART_CR1_UE |

                  USART_CR1_TE |

                  USART_CR1_RE;

    USART2->CR1 = USART_CR1_UE |

                  USART_CR1_TE |

                  USART_CR1_RE;

}

/* ================= POTENTIOMETER ADC ================= */

/*

   Potentiometer:

   Outer pin 1 -> 3.3 V

   Middle pin  -> PA0 / ADC1_IN0

   Outer pin 2 -> GND

   ADC range: 0 to 4095

   Added offset: 0.0% to 8.0%

*/

void Potentiometer_ADC_Init(void)

{

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    /* PA0 analog mode */

    GPIOA->MODER &= ~(3U << 0);

    GPIOA->MODER |=  (3U << 0);

    GPIOA->PUPDR &= ~(3U << 0);

    /* ADC configuration */

    ADC1->CR1 = 0;

    ADC1->CR2 = 0;

    ADC1->SMPR2 &= ~(7U << 0);

    ADC1->SMPR2 |=  (7U << 0);

    ADC1->SQR1 = 0;  /* One conversion */

    ADC1->SQR3 = 0;  /* Channel 0: PA0 */

    ADC1->CR2 |= ADC_CR2_ADON;

}

/* ================= READ POTENTIOMETER ================= */

uint16_t Potentiometer_ReadADC(void)

{

    uint32_t timeout = 1000000U;

    ADC1->SR = 0U;

    ADC1->CR2 |= ADC_CR2_SWSTART;

    while (!(ADC1->SR & ADC_SR_EOC))

    {

        if (--timeout == 0U)

        {

            return 0U;

        }

    }

    return (uint16_t)(ADC1->DR & 0x0FFFU);

}

/* ================= I2C1 INIT ================= */

/* PB6 = SCL, PB7 = SDA */

void I2C1_Init(void)

{

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    GPIOB->MODER &= ~((3U << 12) | (3U << 14));

    GPIOB->MODER |=  ((2U << 12) | (2U << 14));

    GPIOB->OTYPER |= (1U << 6) | (1U << 7);

    GPIOB->AFR[0] &= ~((15U << 24) | (15U << 28));

    GPIOB->AFR[0] |=  ((4U << 24) | (4U << 28));

    GPIOB->PUPDR &= ~((3U << 12) | (3U << 14));

    I2C1->CR1 = I2C_CR1_SWRST;

    I2C1->CR1 = 0;

    I2C1->CR2 = 16U;

    I2C1->CCR = 80U;

    I2C1->TRISE = 17U;

    I2C1->CR1 = I2C_CR1_PE;

}

/* ================= I2C WRITE ================= */

int I2C1_Write(uint8_t data)

{

    uint32_t timeout = 100000U;

    while (I2C1->SR2 & I2C_SR2_BUSY)

    {

        if (--timeout == 0U)

            return 0;

    }

    I2C1->CR1 |= I2C_CR1_START;

    timeout = 100000U;

    while (!(I2C1->SR1 & I2C_SR1_SB))

    {

        if (--timeout == 0U)

            return 0;

    }

    I2C1->DR = (LCD_ADDR << 1);

    timeout = 100000U;

    while (!(I2C1->SR1 & (I2C_SR1_ADDR | I2C_SR1_AF)))

    {

        if (--timeout == 0U)

        {

            I2C1->CR1 |= I2C_CR1_STOP;

            return 0;

        }

    }

    if (I2C1->SR1 & I2C_SR1_AF)

    {

        I2C1->SR1 &= ~I2C_SR1_AF;

        I2C1->CR1 |= I2C_CR1_STOP;

        return 0;

    }

    (void)I2C1->SR1;

    (void)I2C1->SR2;

    timeout = 100000U;

    while (!(I2C1->SR1 & I2C_SR1_TXE))

    {

        if (--timeout == 0U)

        {

            I2C1->CR1 |= I2C_CR1_STOP;

            return 0;

        }

    }

    I2C1->DR = data;

    timeout = 100000U;

    while (!(I2C1->SR1 & I2C_SR1_BTF))

    {

        if (--timeout == 0U)

        {

            I2C1->CR1 |= I2C_CR1_STOP;

            return 0;

        }

    }

    I2C1->CR1 |= I2C_CR1_STOP;

    return 1;

}

/* ================= LCD LOW-LEVEL ================= */

void LCD_ExpanderWrite(uint8_t data)

{

    (void)I2C1_Write(data | LCD_BL);

}

void LCD_Pulse(uint8_t data)

{

    LCD_ExpanderWrite(data | LCD_EN);

    delay_ms(1);

    LCD_ExpanderWrite(data & ~LCD_EN);

    delay_ms(1);

}

void LCD_Write4(uint8_t nibble, uint8_t rs)

{

    uint8_t data = (nibble & 0xF0U) |

                   (rs ? LCD_RS : 0U);

    LCD_ExpanderWrite(data);

    LCD_Pulse(data);

}

void LCD_Send(uint8_t value, uint8_t rs)

{

    LCD_Write4(value & 0xF0U, rs);

    LCD_Write4((value << 4) & 0xF0U, rs);

}

void LCD_Cmd(uint8_t cmd)

{

    LCD_Send(cmd, 0);

    if (cmd == 0x01U || cmd == 0x02U)

        delay_ms(2);

}

void LCD_Data(uint8_t data)

{

    LCD_Send(data, 1);

}

void LCD_String(const char *str)

{

    while (*str)

    {

        LCD_Data((uint8_t)*str++);

    }

}

void LCD_SetCursor(uint8_t row, uint8_t col)

{

    LCD_Cmd((row == 0U ? 0x80U : 0xC0U) + col);

}

/* ================= LCD INIT ================= */

void LCD_Init(void)

{

    delay_ms(50);

    LCD_ExpanderWrite(LCD_BL);

    LCD_Write4(0x30, 0);

    delay_ms(5);

    LCD_Write4(0x30, 0);

    delay_ms(2);

    LCD_Write4(0x30, 0);

    delay_ms(2);

    LCD_Write4(0x20, 0);

    delay_ms(2);

    LCD_Cmd(0x28);  /* 4-bit, 2 lines */

    LCD_Cmd(0x0C);  /* Display ON */

    LCD_Cmd(0x06);  /* Cursor increment */

    LCD_Cmd(0x01);  /* Clear */

    delay_ms(5);

}

/* ================= SENSOR READ ================= */

int ReadSensor(uint8_t *frame)

{

    uint8_t data;

    uint32_t timeout = 1000000U;

    int header_found = 0;

    if (USART1->SR & USART_SR_RXNE)

    {

        data = (uint8_t)USART1->DR;

        (void)data;

    }

    for (int i = 0; i < 4; i++)

    {

        UART_SendByte(SENSOR_UART, sensor_cmd[i]);

    }

    while (timeout > 0U)

    {

        if (USART1->SR & USART_SR_RXNE)

        {

            data = (uint8_t)USART1->DR;

            if (data == 0x16U)

            {

                frame[0] = data;

                header_found = 1;

                break;

            }

        }

        timeout--;

    }

    if (!header_found)

        return 0;

    for (int i = 1; i < 12; i++)

    {

        if (!UART_ReadByte(SENSOR_UART,

                           &frame[i], 1000000U))

        {

            return 0;

        }

    }

    return 1;

}

/* ================= MAIN ================= */

int main(void)

{

    uint8_t frame[12];

    uint16_t oxygen_raw;

    uint16_t pot_adc;

    uint16_t added_raw;

    uint16_t oxygen_scaled;

    char msg[100];

    char lcd_value[17];

    /* HSI 16 MHz */

    RCC->CR |= RCC_CR_HSION;

    while (!(RCC->CR & RCC_CR_HSIRDY))

    {

    }

    RCC->CFGR &= ~((3U << 0)  |

                   (15U << 4) |

                   (7U << 10) |

                   (7U << 13));

    while ((RCC->CFGR & (3U << 2)) != 0U)

    {

    }

    /* SysTick: 1 ms */

    SysTick->LOAD = 16000U - 1U;

    SysTick->VAL = 0;

    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |

                    SysTick_CTRL_ENABLE_Msk;

    UART_Init();

    Potentiometer_ADC_Init();

    I2C1_Init();

    LCD_Init();

    UART_SendString(PC_UART,

                    "\r\nSTM32F401RE Oxygen Sensor\r\n");

    UART_SendString(PC_UART,

                    "USART1 Sensor: 9600 baud\r\n");

    UART_SendString(PC_UART,

                    "USART2 PuTTY: 115200 baud\r\n");

    UART_SendString(PC_UART,

                    "I2C LCD Address: 0x27\r\n");

    UART_SendString(PC_UART,

                    "Potentiometer: PA0, add 0 to 8.0%\r\n");

    LCD_SetCursor(0, 0);

    LCD_String("Oxygen Sensor");

    LCD_SetCursor(1, 0);

    LCD_String("Initializing...");

    delay_ms(1000);

    while (1)

    {

        UART_SendString(PC_UART,

                        "\r\nReading sensor...\r\n");

        if (ReadSensor(frame))

        {

            /* Combine sensor MSB and LSB */

            oxygen_raw =

                ((uint16_t)frame[3] << 8) |

                (uint16_t)frame[4];

            /*

               ADC 0..4095 maps to 0..80 tenths.

               80 tenths = 8.0 percentage points.

               Example:

               Sensor = 21.0%

               Half rotation adds 4.0%

               Final = 25.0%

            */

            pot_adc = Potentiometer_ReadADC();

            added_raw = (uint16_t)

                (((uint32_t)pot_adc * 80U) / 4095U);

            oxygen_scaled = oxygen_raw + added_raw;

            /* PuTTY output */

            snprintf(msg, sizeof(msg),

                     "Sensor: %u.%u %% | "

                     "Pot add: %u.%u %% | "

                     "Final O2: %u.%u %%\r\n",

                     (unsigned int)(oxygen_raw / 10U),

                     (unsigned int)(oxygen_raw % 10U),

                     (unsigned int)(added_raw / 10U),

                     (unsigned int)(added_raw % 10U),

                     (unsigned int)(oxygen_scaled / 10U),

                     (unsigned int)(oxygen_scaled % 10U));

            UART_SendString(PC_UART, msg);

            /* LCD output: show final value only (sensor + potentiometer) */
            snprintf(lcd_value, sizeof(lcd_value),
                     "%u.%u%%",
                     (unsigned int)(oxygen_scaled / 10U),
                     (unsigned int)(oxygen_scaled % 10U));

            LCD_Cmd(0x01);
            LCD_SetCursor(0, 0);
            LCD_String("Final Oxygen:");

            LCD_SetCursor(1, 0);
            LCD_String(lcd_value);

        }

        else

        {

            UART_SendString(PC_UART,

                            "No sensor response\r\n");

            LCD_Cmd(0x01);

            LCD_SetCursor(0, 0);

            LCD_String("Oxygen Sensor");

            LCD_SetCursor(1, 0);

            LCD_String("No Response");

        }

        delay_ms(1000);

    }

}
